package testing;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import dao.BiddingDAO;
import entities.BiddingEntity;
import dao.*;
 

public class BiddingDAOTest {

	
	BiddingDAO biddingDao= new BiddingDAOImplementation();

////1]insert Records Test
//	@Test
//	public void createBiddingDetails()
//	{
//		System.out.println("Test started..");
//		
//		BiddingEntity biddingentity = new BiddingEntity();
//		Assertions.assertTrue(biddingentity!=null);
//		System.out.println("biddingentity created..");
//		
//		biddingentity.setCrop_id(302);
//		biddingentity.setCrop_name("tomato");
//		biddingentity.setBidder_id(704);
//		biddingentity.setBidAmount(6000);
//		
//		biddingDao.insertBiddingDetalis(biddingentity);
//		
//		System.out.println("Test over..");
//		System.out.println();
//	}

// 2] maxBidAmount Test 
	@Test
	public void selectMaxBiddingAmountTest() {
		System.out.println("Test started..");

		Assertions.assertTrue(biddingDao != null);
//			if returns false then Assertion error is thrown
		System.out.println("Got the DAO : " + biddingDao);

		int maxBidAmt = biddingDao.getMaxBiddingAmountForCrop(301);
		System.out.println("BidderEntity Obj : " + maxBidAmt);

		System.out.println("Test over...");
		System.out.println();
	}

//3]selectAllBiddingDetails Test

	@Test
	public void selectAllDetails() {
		System.out.println("Test started..");

		Assertions.assertTrue(biddingDao != null);
		System.out.println("Got the DAO : " + biddingDao);

		List<BiddingEntity> biddingList = new ArrayList<>();
		biddingList = biddingDao.selectAllBiddingDetails(301);
		System.out.println(biddingList);

		System.out.println("Test over...");
		System.out.println();
	}

//4]Select MaxBid Details Test	
	@Test
	public void selectMaxBidDetails() {
		System.out.println("Test started..");

		Assertions.assertTrue(biddingDao != null);
		System.out.println("Got the DAO : " + biddingDao);

		BiddingEntity biddingentity = biddingDao.getDetails(301);
		System.out.println(biddingentity);

		System.out.println("Test over...");
		System.out.println();
	}

}


























