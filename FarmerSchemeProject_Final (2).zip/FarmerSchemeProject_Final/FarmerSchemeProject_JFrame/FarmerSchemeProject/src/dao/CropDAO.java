package dao;

import java.util.List;

import entities.CropDetailsEntity;
import entities.FarmerEntity;

public interface CropDAO {
	public void insertCrop(CropDetailsEntity cropDetailsEntity);

	public CropDetailsEntity selectCrop(int id);
    public List<CropDetailsEntity> selectAllCrop();
//    public List<CropDetailsEntity> selectAllCropNotSold();
	public void updateCrop(CropDetailsEntity cropDetailsEntity);
//	public void updateCropSoldStatus(int id);
	public int selectFarmerId(int id);
	public void deleteCrop(int id);
//	public boolean soldOrNot(int id);

}
