package dao;

import entities.BidderEntity;
import entities.FarmerEntity;

public interface BidderDAO{
	public void insertBidder(BidderEntity bidderEntity);
//	public void insertFarmer(FarmerEntity farmerEntity);
	public BidderEntity selectBidder(int id);
	public void updateBidder(BidderEntity BidderEntity);
	public void deleteBidder(int id);
//	void updateAmountBidder(BidderEntity BidderrEntity, int bidder_id, int amt);
//	public int maxIdBidder();
}
