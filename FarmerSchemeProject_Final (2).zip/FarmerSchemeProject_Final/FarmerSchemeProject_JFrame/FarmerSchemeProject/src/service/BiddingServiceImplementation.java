package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import entities.BiddingEntity;
import dao.BiddingDAO;
import dao.BiddingDAOImplementation;
import dao.*;
import dao.BaseConnectionClass;

public class BiddingServiceImplementation extends BaseConnectionClass implements BiddingService {
    BiddingDAO biddingDaoObj=new BiddingDAOImplementation();
	@Override
	public void insertBiddingDetalisService(BiddingEntity biddingEntity) {
		// TODO Auto-generated method stub
		biddingDaoObj.insertBiddingDetalis(biddingEntity);
		
	}

	@Override
	public int getMaxBiddingAmountForCropService(int cropId) {
		// TODO Auto-generated method stub
		
		
        int maxBidAmount = 0;
     
        try 
        {
        	PreparedStatement pst = conn.prepareStatement("SELECT MAX(BID_AMOUNT) AS maxBidAmount FROM BIDDING_DETAILS WHERE CROP_ID = ? GROUP BY crop_id");
        	
        	pst.setInt(1, cropId);
        	
            ResultSet result = pst.executeQuery();
            if (result.next()) {
                maxBidAmount = result.getInt("maxBidAmount");
        }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return maxBidAmount;
    
	
	
	
		
	}
	
	
	public BiddingEntity getDetailsSerice(int cropID) {
		BiddingEntity biddingEntity=new BiddingEntity();
		   int amt=getMaxBiddingAmountForCropService(cropID);
		   System.out.println(amt);
		try {
			
        	Statement statement = conn.createStatement();
			String sqlQuery="SELECT * FROM BIDDING_DETAILS WHERE CROP_ID = "+cropID+" and BID_AMOUNT= "+amt;
			System.out.println(sqlQuery);
			ResultSet result=statement.executeQuery(sqlQuery);
            while (result.next()) 
            {
            	biddingEntity.setCrop_id(cropID);
            	biddingEntity.setCrop_name(result.getString(2));
            	biddingEntity.setBidder_id(result.getInt(3));
            	biddingEntity.setBidAmount(result.getInt(4));
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
		return biddingEntity;
	}
	

	

	@Override
	public List<BiddingEntity> selectAllBiddingDetailsService(int cropId) {
		// TODO Auto-generated method stub
		return biddingDaoObj.selectAllBiddingDetails(cropId);
	}

//	@Override
//	public BiddingEntity getDetailsSerice(int cropID) {
//		// TODO Auto-generated method stub
//		return biddingDaoObj.getDetails(cropID);
//	}

}
