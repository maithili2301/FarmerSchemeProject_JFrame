package service;

import java.util.List;

import entities.BiddingEntity;

public interface BiddingService {
	public void insertBiddingDetalisService(BiddingEntity biddingEntity);  // insertRecords
	public int getMaxBiddingAmountForCropService(int cropId); //Max bid
	public List<BiddingEntity> selectAllBiddingDetailsService(int cropId); //bidding Details
	public BiddingEntity getDetailsSerice(int cropID);
	
}
