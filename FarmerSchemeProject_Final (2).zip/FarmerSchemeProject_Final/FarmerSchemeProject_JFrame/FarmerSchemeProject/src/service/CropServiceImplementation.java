package service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entities.CropDetailsEntity;
import dao.BaseConnectionClass;
import dao.CropDAO;
import dao.CropDAOImplementation;

public class CropServiceImplementation extends BaseConnectionClass implements CropService {

	CropDAO cropDaoObj=new CropDAOImplementation();
	@Override
	public void insertCropService(CropDetailsEntity cropDetailsEntity) {
		// TODO Auto-generated method stub
		cropDaoObj.insertCrop(cropDetailsEntity);
		
	}

	@Override
	public CropDetailsEntity selectCropService(int id) {
		// TODO Auto-generated method stub
		return cropDaoObj.selectCrop(id);
	}

	@Override
	public List<CropDetailsEntity> selectAllCropService() {
		// TODO Auto-generated method stub
		return cropDaoObj.selectAllCrop();
	}

	@Override
	public List<CropDetailsEntity> selectAllCropNotSoldService() {
		
			List<CropDetailsEntity> cropList = new ArrayList<CropDetailsEntity>();
			try {
				Statement statement = conn.createStatement();
				ResultSet result = statement.executeQuery("select * from CROP_DETAILS where SOLD_OR_NOT='Not Sold'");
				while (result.next()) {
					CropDetailsEntity cropEntity = new CropDetailsEntity();
					cropEntity.setCropId(result.getInt(1));
					cropEntity.setCropName(result.getString(2));
					cropEntity.setFertilizerType(result.getString(3));
					cropEntity.setQuntity(result.getString(4));
					cropEntity.setSoilpHCertificate(result.getString(5));
					cropEntity.setFarmer_ID(result.getInt(6));
					cropList.add(cropEntity);
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return cropList;
		
	}

	@Override
	public void updateCropService(CropDetailsEntity cropDetailsEntity) {
		// TODO Auto-generated method stub
		cropDaoObj.updateCrop(cropDetailsEntity);
		
	}

	@Override
	public void updateCropSoldStatusService(int id) {
		
			String S = "Sold";
			try {
				String sql = "UPDATE CROP_DETAILS SET SOLD_OR_NOT= '" + S + " ' WHERE CROP_ID=" + id;
				System.out.println(sql);
				PreparedStatement pst = conn.prepareStatement(sql);
				pst.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}

	@Override
	public int selectFarmerIdService(int id) {
		// TODO Auto-generated method stub
		return cropDaoObj.selectFarmerId(id);
	}

	@Override
	public void deleteCropService(int id) {
		// TODO Auto-generated method stub
		cropDaoObj.deleteCrop(id);
		
	}

	@Override
	public boolean soldOrNotService(int id) {
	
			String s="Sold";
			
			boolean sold=false;
			try {
				Statement statement = conn.createStatement();
				ResultSet result = statement.executeQuery("select SOLD_OR_NOT from CROP_DETAILS where CROP_ID=" + id);
				if (result.next()) {
	                 System.out.println("Inside if");
					 s= result.getString(1);
					System.out.println("["+s+"]");
					
					if (s.equals("Not Sold")) {
						System.out.println("Returning true");
						sold=true;
						
					}else {
						System.out.println("Returning false");

						sold=false;
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

			return sold;

		}
	

}
